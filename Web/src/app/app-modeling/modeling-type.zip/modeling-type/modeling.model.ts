export class manualmodeling{
    splitmethod:string
}