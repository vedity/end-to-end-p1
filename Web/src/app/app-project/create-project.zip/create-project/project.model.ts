export class createproject{
    projectname:string;
    description:string;
    datasetdescription:string;
    datasetname:string;
    file:string;
    inputfile:File;
    datsetid:string;
    isprivate:boolean;    
}