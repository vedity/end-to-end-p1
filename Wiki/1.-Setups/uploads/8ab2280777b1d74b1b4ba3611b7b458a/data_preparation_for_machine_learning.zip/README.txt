Data Preparation for Machine Learning
=====================================

README
------

Welcome to Data Preparation for Machine Learning!

Your package contains:

1. README (this file)
	README.txt
2. The Ebook:
	data_preparation_for_machine_learning.pdf
3. Code Recipes:
	code/

The code directory provides access to all of the data and code examples used in the book.

Any questions at all, contact me direction via email: jason@MachineLearningMastery.com

Kind Regards,

Jason.